let x="               REPORT CARD";
console.log(x);

var name="Name           :- Manish Vishwakarma";
console.log(name);

var School_name="School Name    :- Chrish Church Convent";
console.log(School_name);

var grade="Grade          :-12th";
console.log(grade);

var section="Section        :-A",     RollNo="RollNo :-1212";
console.log(section,RollNo);

var marks="Subject        :  Max.Marks   :MarksObtained";
console.log(marks);
var result="Maths          :    100       :   90";
console.log(result);

var sci="Science        :    100       :   91";
console.log(sci);
var eng="English        :    100      :   92";
console.log(eng);