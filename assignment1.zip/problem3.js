var name="Manish Vishwakarma";
console.log(name);
console.log(typeof (name));

var age=25;
console.log(age);
console.log(typeof (age));