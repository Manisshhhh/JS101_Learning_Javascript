let x="Masai School";

console.log(x);

let y= "A Transformation in Education";
console.log(y);
