var name="My Name-Manish Vishwakarma";
console.log(name);

var name="Fathers Name-Madan Vishwakarma";
console.log(name);

var name="Mothers Name-Phoola Vishwakarma";
console.log(name);
